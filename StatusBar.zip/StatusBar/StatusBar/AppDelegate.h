//
//  AppDelegate.h
//  StatusBar
//
//  Created by lailin on 17/6/8.
//  Copyright © 2017年 lailin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

